# Demo Flexbox 2

A Pen created on CodePen.io. Original URL: [https://codepen.io/antonbeletsky/pen/LYmqLoQ](https://codepen.io/antonbeletsky/pen/LYmqLoQ).

Forked from [Hugo Giraudel](http://codepen.io/HugoGiraudel/)'s Pen [Demo Flexbox 2](http://codepen.io/HugoGiraudel/pen/pkwqH/).