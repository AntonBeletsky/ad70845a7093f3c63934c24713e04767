window.addEventListener('DOMContentLoaded', function() {
  
  var navbar = document.querySelector('.navbar');
  if (navbar) {
    
    function toggleItem(el) {
      var item = el.classList.contains('navbar-main-group') ? el : el.closest('.navbar-main-group');
      if (!item) return;
      
      var opened = navbar.querySelector('.navbar-main-group-selected');
      if (opened) {
        if (opened == item) {
          // Close
          opened.classList.remove('navbar-main-group-selected');
          if (opened.classList.contains('navbar-main-group-fullscreen')) {
            navbar.classList.remove('navbar-main-group-opened');
          }
          
          return;
        }
        opened.classList.remove('navbar-main-group-selected');
      }
      
      item.classList.add('navbar-main-group-selected');
      
      if (item.classList.contains('navbar-main-group-fullscreen')) {
        navbar.classList.add('navbar-main-group-opened');
      } else {
        navbar.classList.remove('navbar-main-group-opened');
      }
    }
    
    navbar.addEventListener('click', function(event) {
      if (event.target.classList.contains('navbar-main-item-title') || event.target.closest('.navbar-main-item-title')) {
        toggleItem(event.target);
      }
    });
    
  }
  
})