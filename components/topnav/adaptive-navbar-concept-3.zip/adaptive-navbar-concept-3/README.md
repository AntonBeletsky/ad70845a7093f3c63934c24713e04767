# Adaptive NavBar concept 3

A Pen created on CodePen.io. Original URL: [https://codepen.io/antonbeletsky/pen/dyeZLjy](https://codepen.io/antonbeletsky/pen/dyeZLjy).

