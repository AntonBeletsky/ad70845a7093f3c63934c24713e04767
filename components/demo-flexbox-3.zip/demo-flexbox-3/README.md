# Demo Flexbox 3

A Pen created on CodePen.io. Original URL: [https://codepen.io/antonbeletsky/pen/NWMogVK](https://codepen.io/antonbeletsky/pen/NWMogVK).

Forked from [Hugo Giraudel](http://codepen.io/HugoGiraudel/)'s Pen [Demo Flexbox 3](http://codepen.io/HugoGiraudel/pen/qIAwr/).